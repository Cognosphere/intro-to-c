#include <stdio.h>

int main(void) {
	int x;
scanf("%d", &x);
printf("You entered %d", x);
return 0;
}

