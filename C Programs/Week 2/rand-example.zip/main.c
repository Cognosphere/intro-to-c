#include <stdio.h>
#include <stdlib.h>

int main(void) {
 int int1 = rand()%100;
 printf("%d", int1);
 return 0;
}

