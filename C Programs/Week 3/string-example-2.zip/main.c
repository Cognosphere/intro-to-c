#include <stdio.h>

int main(void) {
 char string[10];
 printf("Enter string: ");
 scanf("%s", string);
 printf("You entered %s", string);
 
 return 0;
}


