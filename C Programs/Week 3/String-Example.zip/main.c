#include <stdio.h>

int main(void) {
 char string[] = "Hello";
 printf("%s", string);
 return 0;
}

