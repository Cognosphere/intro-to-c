#include <stdio.h>

int main(void) {
char n = 'c';
printf("%c", n);
return 0;
}


