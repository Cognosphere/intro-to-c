
#include <stdio.h>

int main(void) {
 int array[10] = {1,2,3,4,5,6,7,8,9,10};
 printf("Element 6 of the list is %d", array[6]);
 return 0;
}

