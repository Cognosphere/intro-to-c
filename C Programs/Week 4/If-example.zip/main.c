#include <stdio.h>

int main(void) {
  int x = 10;
  if(x == 10){
    printf("Hello World\n");
  }
  return 0;
}