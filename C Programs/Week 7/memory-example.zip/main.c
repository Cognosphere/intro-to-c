#include <stdio.h>

int main(void) {
 int x;
 printf("Variable location of x: %p\n",&x);
 return 0;
}
