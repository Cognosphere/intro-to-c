#include <stdio.h>

int main(void) {
 int int1 = 5;
 int int2 = 1;
 int answer = int1+int2;
 printf("%d + %d = %d", int1, int2, answer);
 return 0;
}

