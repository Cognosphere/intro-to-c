#include <stdio.h>

int main(void) {
 int x = 0;
 while(x <= 10){
   printf("Hello World\n");
   x++;
 } //prints Hello World 10 times
 return 0;
}
