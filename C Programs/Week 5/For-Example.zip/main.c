#include <stdio.h>

int main(void) {
 for(int x=0;x<=10;x++){
   printf("Hello World\n");
 } //prints Hello World 10 times
 return 0;
}
